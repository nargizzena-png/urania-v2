<?php $page_title = 'Servicii'; include 'includes/header.php'; ?>

<a href="#main-content" class="skip-to-content">Sari la conținutul principal</a>

<main id="main-content">

<section class="section" id="servicii-grid" aria-labelledby="servicii-title">
    <h1 id="servicii-title" class="sr-only">Serviciile noastre</h1>
    <div class="container">
        <div class="cards-grid" role="list">

            <article class="service-card reveal" id="video" role="listitem">
                <img src="images/servicii/08-productie-cinematografica.png" alt="" loading="lazy" decoding="async" class="service-card-img" aria-hidden="true">
                <h2 class="service-title">Producție Video &amp; Film</h2>
                <span class="card-sub">Filmare &middot; Montaj &middot; Post-Producție</span>
                <a href="contact.php" class="btn-gold" aria-label="Cere ofertă pentru Producție Video și Film">Cere ofertă</a>
            </article>

            <article class="service-card reveal reveal-delay-1" id="audio" role="listitem">
                <img src="images/servicii/02-muzica-concerte.png" alt="" loading="lazy" decoding="async" class="service-card-img" aria-hidden="true">
                <h2 class="service-title">Podcast &amp; Producție Audio</h2>
                <span class="card-sub">Înregistrare &middot; Mixaj &middot; Mastering</span>
                <a href="contact.php" class="btn-gold" aria-label="Cere ofertă pentru Podcast și Producție Audio">Cere ofertă</a>
            </article>

            <article class="service-card reveal reveal-delay-2" id="evenimente" role="listitem">
                <img src="images/servicii/04-afterwork.png" alt="" loading="lazy" decoding="async" class="service-card-img" aria-hidden="true">
                <h2 class="service-title">Organizare Evenimente</h2>
                <span class="card-sub">Concept &middot; Producție &middot; Logistică</span>
                <a href="contact.php" class="btn-gold" aria-label="Cere ofertă pentru Organizare Evenimente">Cere ofertă</a>
            </article>

        </div>
    </div>
</section>

<section class="section section-dark" id="servicii-cta" aria-labelledby="servicii-cta-heading">
    <div class="container narrow">
        <span class="section-label reveal">Colaborare</span>
        <h2 class="section-title reveal" id="servicii-cta-heading">Aveți un proiect în minte?</h2>
        <div class="gold-line gold-line-center reveal" aria-hidden="true"></div>
        <p class="section-desc reveal">Spuneți-ne ideea voastră și construim împreună soluția potrivită.</p>
        <div class="btn-group compact reveal">
            <a href="contact.php" class="btn-gold btn-gold-fill" aria-label="Propune un proiect nou">Propune un proiect</a>
        </div>
    </div>
</section>

</main>

<?php include 'includes/footer.php'; ?>
